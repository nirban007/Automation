import socket

host = 'localhost'
port = 1234

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((host, port))
s.listen(5)

print(f"Server started on {host}:{port}")

while True:
    client_socket, client_address = s.accept()
    print(f"Accepted connection from {client_address[0]}:{client_address[1]}")

    # Handle client connection logic here

    client_socket.close()
