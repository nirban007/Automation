import socket

host = 'localhost'
port = 1234

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((host, port))

# Example data to send
data = "Hello, server!"

# Send data to the server
client_socket.send(data.encode())

# Receive response from the server
response = client_socket.recv(6430)
print(f"Received response: {response.decode()}")

# Close the client socket
client_socket.close()




