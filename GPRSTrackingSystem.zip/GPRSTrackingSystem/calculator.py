def addition(first,second):
    result = first + second
    print(result);
def sub(first,second):
    result = first - second
    print(result);
def mul(first,second):
    result = first * second
    print(result);
def div(first,second):
    try:
        result = first / second
        print(result)
    except:
        print('Division Error')

while True:
    first = int(input("Enter first number:"))
    symp = input("(+,-,*,/)")
    second = int(input("Input Second number: "))

    if(symp == '+'):
        addition(first,second)
    elif(symp == '-'):
        sub(first, second)

    elif(symp == '*'):
        mul(first, second)

    elif (symp == '/'):
        div(first, second)

    else:
        print("Wrong Chose")
